<?php
/**
 * TGM Plugin Activator
 */
function sh_tgmpa_message() { ?>
    <div class="shufflehound-dashboard-message">
        <h1>Install Plugins</h1>
        <p>
            Install our required plugins for Unyson Framework and WPbakery Page Builder, and choose which recommended plugins you will be using.
            For example, choose WooCommerce shop plugin only if you are going to build a store.
        </p>
    </div>
<?php }
