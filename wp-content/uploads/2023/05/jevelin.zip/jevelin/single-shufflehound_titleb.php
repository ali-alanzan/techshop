<?php
/* Template Name: Titlebars */
get_header(); ?>

<div class="sh-titlebar sh-titlebar-template">
    <div class="container">
        <?php the_content(); ?>
    </div>
</div>

<?php get_footer(); ?>
